package com.wms.CUSTOMER;

import com.wms.ADMIN.LoginFrame;
import com.wms.models.UserData;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.sql.*;
import java.util.List;

public class OrderCreationPage extends JFrame {

    private JTextField searchField;
    private JComboBox<String> sortOptions;
    private JTextField  productIdField, productDetailsField, quantityField;
    private JButton placeOrderButton, backButton, logoutButton, searchButton, sortbutton;
    private JTable ordersTable;
    private DefaultTableModel ordersTableModel;

    public OrderCreationPage(UserData currentUser) {
        setTitle("Create Order");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        getContentPane().setLayout(new BorderLayout());

        // Top Panel for Search and Sort
        JPanel searchSortPanel = new JPanel(new GridBagLayout());
        searchSortPanel.setBackground(Color.WHITE);
        searchField = new JTextField(20);
        searchField.setFont(new Font("Arial", Font.BOLD, 24));

        String[] sortChoices = {"Order ID (ASC)", "Order ID (DESC)"};
        sortOptions = new JComboBox<>(sortChoices);
        sortOptions.setFont(new Font("Arial", Font.BOLD, 24));

        searchButton = createStyledButton("Search", "icons/search.png");
        searchButton.setFont(new Font("Arial", Font.PLAIN, 18));
        searchButton.addActionListener(e -> searchOrders());
        sortbutton = createStyledButton("Sort", "icons/sort.png");
        sortbutton.setFont(new Font("Arial", Font.PLAIN, 18));
        sortbutton.addActionListener(e -> sortOrders());
        GridBagConstraints searchSortGbc = new GridBagConstraints();
        searchSortGbc.fill = GridBagConstraints.HORIZONTAL;
        searchSortGbc.insets = new Insets(5, 5, 5, 5);
        searchSortGbc.gridx = 0;
        searchSortGbc.gridy = 0;
        searchSortPanel.add(searchField, searchSortGbc);
        searchSortGbc.gridx = 1;
        searchSortPanel.add(searchButton, searchSortGbc);
        searchSortGbc.gridx = 2;
        searchSortPanel.add(sortOptions, searchSortGbc);
        searchSortGbc.gridx = 3;
        searchSortPanel.add(sortbutton, searchSortGbc);

        // Add searchSortPanel to the top of the main layout
        getContentPane().add(searchSortPanel, BorderLayout.NORTH);

        // Create Order Panel on the right
        JPanel orderCreationPanel = new JPanel(new GridBagLayout());
        orderCreationPanel.setBackground(Color.WHITE);
        orderCreationPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));


        JLabel productIdLabel = new JLabel("Product ID:");
        productIdLabel.setForeground(Color.BLACK);
        productIdLabel.setFont(new Font("Arial", Font.BOLD, 24));
        productIdField = new JTextField(10);
        productIdField.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel productDetailsLabel = new JLabel("Product Details:");
        productDetailsLabel.setForeground(Color.BLACK);
        productDetailsLabel.setFont(new Font("Arial", Font.BOLD, 24));
        productDetailsField = new JTextField(10);
        productDetailsField.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setForeground(Color.BLACK);
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 24));
        quantityField = new JTextField(10);
        quantityField.setFont(new Font("Arial", Font.BOLD, 24));

        placeOrderButton = createStyledButton("Place Order", "icons/place_order.png");
        placeOrderButton.setFont(new Font("Arial", Font.BOLD, 24));
        placeOrderButton.addActionListener(e -> placeOrder(currentUser));

        GridBagConstraints creationGbc = new GridBagConstraints();
        creationGbc.fill = GridBagConstraints.HORIZONTAL;
        creationGbc.insets = new Insets(5, 5, 5, 5);


        creationGbc.gridx = 0;
        creationGbc.gridy = 1;
        orderCreationPanel.add(productIdLabel, creationGbc);
        creationGbc.gridx = 1;
        orderCreationPanel.add(productIdField, creationGbc);

        creationGbc.gridx = 0;
        creationGbc.gridy = 2;
        orderCreationPanel.add(productDetailsLabel, creationGbc);
        creationGbc.gridx = 1;
        orderCreationPanel.add(productDetailsField, creationGbc);

        creationGbc.gridx = 0;
        creationGbc.gridy = 3;
        orderCreationPanel.add(quantityLabel, creationGbc);
        creationGbc.gridx = 1;
        orderCreationPanel.add(quantityField, creationGbc);

        creationGbc.gridx = 0;
        creationGbc.gridy = 4;
        creationGbc.gridwidth = 2;
        orderCreationPanel.add(placeOrderButton, creationGbc);

        // Add the orderCreationPanel to the right of the main layout
        getContentPane().add(orderCreationPanel, BorderLayout.EAST);

        // Orders Table in the center
        String[] orderColumns = {"Order ID", "Username", "Product ID", "Product Details", "Quantity", "Status", "Tracking ID", "Order Details"};
        ordersTableModel = new DefaultTableModel(orderColumns, 0);
        ordersTable = new JTable(ordersTableModel);
        styleTable(ordersTable);
        JScrollPane orderScrollPane = new JScrollPane(ordersTable);
        orderScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        orderScrollPane.setPreferredSize(new Dimension(800, 600));

        getContentPane().add(orderScrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Centered with padding

        backButton = createStyledButton("Back", "icons/back.png");
        backButton.addActionListener(e -> dispose());
        logoutButton = createStyledButton("Logout", "icons/logout.png");
        logoutButton.addActionListener(e -> {
            dispose();
            try {
                new LoginFrame().setVisible(true);  // Return to login page
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });


        buttonPanel.add(backButton);

        buttonPanel.add(logoutButton);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        // Load initial data
        loadOrdersData(currentUser);
    }

    // Search orders based on the input in the searchField
    private void searchOrders() {
        String searchText = searchField.getText().toLowerCase();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(ordersTableModel);
        ordersTable.setRowSorter(sorter);
        sorter.setRowFilter(RowFilter.regexFilter(searchText));
    }

    // Sort orders based on the selected option in sortOptions
    private void sortOrders() {
        String selectedOption = (String) sortOptions.getSelectedItem();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(ordersTableModel);
        ordersTable.setRowSorter(sorter);

        if (selectedOption != null) {
            switch (selectedOption) {
                case "Order ID (DESC)":
                    sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING)));
                    break;
                case "Order ID (ASC)":
                    sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.DESCENDING)));
                    break;

            }
        }
    }


    private void styleTable(JTable table) {
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(30);
        table.setSelectionBackground(Color.LIGHT_GRAY);
        table.setGridColor(Color.GRAY);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setBackground(new Color(255, 110, 110));
        header.setForeground(Color.WHITE);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }

    private JButton createStyledButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setIcon(new ImageIcon(iconPath));
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setBackground(new Color(255, 110, 110)); // Custom orange color
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        button.setPreferredSize(new Dimension(200, 50));

        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/" + iconPath));
            button.setIcon(icon);
        } catch (Exception e) {
            System.err.println("Icon not found: " + iconPath);
            e.printStackTrace();
        }
        return button;
    }

    private void loadOrdersData(UserData currentUser) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.0.200:3306/wms1", "LAP", "root");
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT o.order_id, u.username, o.product_id, o.product_details, o.quantity, o.status, o.tracking_id, o.order_deatils " +
                             "FROM orders o JOIN users u ON o.user_id = u.user_id " +
                             "WHERE u.username = ? AND o.status NOT IN ('Delivered', 'Canceled')"
             )) {

            // Set the current user's username in the query
            stmt.setString(1, currentUser.getUsername());

            try (ResultSet rs = stmt.executeQuery()) {
                // Clear existing data
                ordersTableModel.setRowCount(0);

                // Add data to the table
                while (rs.next()) {
                    int orderId = rs.getInt("order_id");
                    String username = rs.getString("username");
                    int productId = rs.getInt("product_id");
                    String productDetails = rs.getString("product_details");
                    int quantity = rs.getInt("quantity");
                    String status = rs.getString("status");
                    String trackingId = rs.getString("tracking_id");
                    String orderDetails = rs.getString("order_deatils");

                    ordersTableModel.addRow(new Object[]{orderId, username, productId, productDetails, quantity, status, trackingId, orderDetails});
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void placeOrder(UserData currentUser) {
        // Use the current user's username
        String username = currentUser.getUsername();
        String productIdStr = productIdField.getText();
        String quantityStr = quantityField.getText();
        String productDetails = productDetailsField.getText();

        if (productIdStr.isEmpty() || quantityStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.0.200:3306/wms1", "LAP", "root")) {
            // Retrieve user_id based on the current user's username
            PreparedStatement userStmt = conn.prepareStatement("SELECT user_id FROM users WHERE username = ?");
            userStmt.setString(1, username);
            ResultSet userResult = userStmt.executeQuery();

            if (userResult.next()) {
                int userId = userResult.getInt("user_id");
                int productId = Integer.parseInt(productIdStr);
                int quantity = Integer.parseInt(quantityStr);

                // Generate a unique tracking ID with small letters and numbers
                String trackingId = generateUniqueTrackingId();

                // Insert order into the database
                String insertOrderSQL = "INSERT INTO orders (user_id, product_id, quantity, status, tracking_id, product_details) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertOrderSQL)) {
                    insertStmt.setInt(1, userId);
                    insertStmt.setInt(2, productId);
                    insertStmt.setInt(3, quantity);
                    insertStmt.setString(4, "Processing");  // Default status
                    insertStmt.setString(5, trackingId);
                    insertStmt.setString(6, productDetails);

                    insertStmt.executeUpdate();

                    // Display tracking ID to the user
                    JOptionPane.showMessageDialog(this, "Order placed successfully. Tracking ID: " + trackingId);
                    loadOrdersData(currentUser);  // Reload the table data
                }
            } else {
                JOptionPane.showMessageDialog(this, "Username not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to generate a unique tracking ID
    private String generateUniqueTrackingId() {
        String characters = "abcdefghijklmnopqrstuvwxyz0123456789"; // Lowercase letters and numbers
        StringBuilder trackingId = new StringBuilder("TRACK");

        for (int i = 0; i < 6; i++) { // Adjust length as needed
            int randomIndex = (int) (Math.random() * characters.length());
            trackingId.append(characters.charAt(randomIndex));
        }

        return trackingId.toString();
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserData userData = new UserData("john_doe", "Admin", 1, "email@example.com", "1234567890", "123 Main St", "First Name", "Last Name", "null");
            new OrderCreationPage(userData).setVisible(true);
        });
    }
}

